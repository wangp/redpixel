void blast(int x, int y, int dmg, int tag);
