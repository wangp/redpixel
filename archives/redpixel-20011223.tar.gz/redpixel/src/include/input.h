#ifndef __included_input_h
#define __included_input_h


/* inp_peer.c */
void send_local_input();
int recv_remote_inputs();

/* inp_demo.c */
int recv_demo_inputs();


#endif
