#ifndef __included_cpu_h
#define __included_cpu_h


extern int cpu_num;
extern int cpu_agressiveness;
extern char *cpu_angst_str[5];


void do_cpu();


#endif
