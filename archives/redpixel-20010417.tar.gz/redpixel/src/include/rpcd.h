#ifndef __included_rpcd_h
#define __included_rpcd_h


void rpcd_init();
void rpcd_shutdown();
void rpcd_play_random_track();


#endif
