

{12}                    r {4}. {12}e {4}. {12}d   {4}.   {12}p {4}.{12}i {4}. {12}x {4}. {12}e {4}. {12}l


{4}                      copyright 1998 psyk software


{4}                            -   -   -   -   -


{12}#include <std_disclaimer.h>

{4}   "I do not accept responsibility for any effects, adverse or otherwise, 
{4}    that this code may have on you, your computer, your sanity, your dog, 
{4}    and anything else that you can think of. Use it at your own risk."


{12}Story

{4}    You have been thrown in a dungeon with a handful of other prisoners.
{4}    Contained within the dungeon are various magical objects, mostly weapons,
{4}    which respawn after a certain time period.

{4}    Surrounded by such weapons of destruction, you cannot resist the
{4}    temptation. {12}You must kill something!


{12}Controls

{4}    Move your little man with the keyboard:

{12}            W               T                   Up
{12}        A   S   D       F   G   H       Left    Down    Right

{4}    Aim his gun with the mouse. 

{12}        Left click to shoot. 

{4}    On the left of the screen the weapons you collect will be displayed.

{12}        Right click on them to select.

{12}        Or use the number keys across the top of the keyboard.

{12}        Press Enter to drop a mine.

{4}    Other stuff:

{12}        TAB to see your scores.

{12}        ESC to quit.


{12}Completeness

{4}    Red Pixel is only 70% completed. There is still IPX and Internet play
{4}    to be done.  It is possible I will do IPX soon, if there is any interest,
{4}    but Internet play is a little harder, so may never see the light of day.

{4}    BTW, if anyone wants, you can get the source code from me and do it 
{4}    yourself.


{12}Contact

{4}    Email me at tjaden@alphalink.com.au, or tjaden@psynet.net (which will 
{4}    redirect to whatever mail account I use at that time)

{4}    Tell me what you think, and if you find any bugs, well.. keep quiet. :)

