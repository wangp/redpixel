long longrand(long randomnum);
long slongrand(unsigned long seed);
