void suicide(char *s);
