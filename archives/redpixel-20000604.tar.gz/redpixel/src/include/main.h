#ifndef __included_main_h
#define __included_main_h


extern int record_demos;
extern int filtered;


void shutdown();


#endif
