// for the benefit of the SeeR scripts
// (enums not supported yet -- v0.6a)
#define w_knife     1
#define w_pistol    2
#define w_bow       3
#define w_shotgun   4
#define w_uzi       5
#define w_m16       6
#define w_minigun   7
#define w_bazooka   8
#define w_mine      9
#define num_weaps   10