/*----------------------------------------------------------------
 * timer.h - Libnet's timer function
 *----------------------------------------------------------------
 *  libnet is (c) Copyright Chad Catlett and George Foot 1997-1999
 *
 *  Please look in `docs' for details, documentation and
 *  distribution conditions.
 */


#ifndef libnet_included_file_timer_h
#define libnet_included_file_timer_h


extern unsigned int (*__libnet_timer_func) (void);


#endif

