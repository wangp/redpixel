#ifndef __included_scrblit_h
#define __included_scrblit_h


void blit_to_screen_offset(BITMAP *buffer, int, int);
void blit_to_screen(BITMAP *buffer);


#endif
