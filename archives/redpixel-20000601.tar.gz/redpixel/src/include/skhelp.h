void send_long(long val);
long recv_long();
