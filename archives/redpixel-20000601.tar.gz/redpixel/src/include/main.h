#ifndef __included_main_h
#define __included_main_h


extern int record_demos;

void shutdown();


#endif
