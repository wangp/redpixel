#ifndef _included_version_h_
#define _included_version_h_

#define VERSION_STR "v0.9"
#define VERSION_YEAR "1998-9"

/* experimental - i.e. does not work! */
/*#define MODEM_CODE*/

#endif
