
		      {12}r e d {4}� {12}p i x e l

		{4}copyright psyk software 1998
		    {4}all rights reserved
			{4}and all that

			 {12}-   -   - 

    {12}note {4}this game is unfinished
	 {4}this readme is boring
	 {4}the sounds need work
	 {4}ipx and internet play are not implemented yet
	 {12}not to be distributed, yet

    {12}to play {4}connect two puters via serial cable to com2
	    {4}have your mice plugged into com1 or something
	    {4}run 'red' on both computers
	    {4}it should automagically connect

    {12}controls {4}use the mouse to aim
	     {4}left click to shoot
	     {4}right click on weapon icon to switch weapons

	     {4}use the keyboard to move :-

		 {4}up down left right
		 {4}w s a d
		 {4}t g f h
		 {4}i k j l

	     {4}tab to see frags
		 {4}note: they will all say 'tjaden' (for now)

	     {4}f12 to see fps

	     {4}esc to quit

    {12}credits
	{4}    code: {12}peter wang
	{4}graphics: {12}david wang
	{4}  sounds: various sources including doom, cyberdogs, dune2, 
					    {4}commando, mech2 demo










	{2}Enjoy the death while you can.

	{8}wow, uppercase and a different colour







