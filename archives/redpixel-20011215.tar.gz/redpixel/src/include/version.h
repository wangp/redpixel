#define VERSION_STR 	"1.0"
#define VERSION_YEAR 	"1998-2001"

