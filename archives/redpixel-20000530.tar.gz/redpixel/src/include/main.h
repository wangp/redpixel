#ifndef __included_main_h
#define __included_main_h


extern int com_port;
extern int record_demos;


void shutdown();


#endif
