#define VERSION_STR 	"v0.11"
#define VERSION_YEAR 	"1998-2000"

