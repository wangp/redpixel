#ifndef __included_mousespr_h
#define __included_mousespr_h


void set_stretched_mouse_sprite(BITMAP *sprite, int factor, int hotx, int hoty);
void free_stretched_mouse_sprite(void);


#endif
