#ifndef __included_sound_h
#define __included_sound_h


void snd_local(int snd);
void snd_3d(int snd, int maxvol, int sourcex, int sourcey);


#endif
