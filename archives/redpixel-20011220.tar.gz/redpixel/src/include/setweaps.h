void set_weapon_stats();
