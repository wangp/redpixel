#ifndef _included_rg_rand_h_
#define _included_rg_rand_h_

long longrand(long randomnum);
long slongrand(unsigned long seed);

#endif
