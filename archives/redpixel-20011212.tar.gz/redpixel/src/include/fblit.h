#ifndef __included_fblit_h
#define __included_fblit_h


void fblit(BITMAP *src, BITMAP *dest);
void fblit_init(RGB *pal);


#endif

