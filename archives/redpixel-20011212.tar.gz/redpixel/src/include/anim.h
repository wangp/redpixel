/* animation speeds */

#define MINE_ANIM       10
#define EXPLO_ANIM      5
#define LEG_ANIM        3	/* used to be 1! :) */
#define HEART_ANIM      7
#define MSG_ANIM        140
#define CORPSE_ANIM     12

