#ifndef __included_agup_h
#define __included_agup_h


void rpagup_init(void);
void rpagup_shutdown(void);


#endif
