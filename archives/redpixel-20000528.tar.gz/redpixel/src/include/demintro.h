#ifndef __included_demintro_h
#define __included_demintro_h

void introduce_demo();
void introduce_map();

#endif
