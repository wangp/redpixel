#define VERSION_STR 	"v0.10"
#define VERSION_YEAR 	"1998-2000"

