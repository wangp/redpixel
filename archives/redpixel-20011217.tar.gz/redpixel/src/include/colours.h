/* GAMEPAL dependent */

#define BLACK		0
#define DARKGREY	8
#define DARKGRAY	DARKGREY
#define GREY    	16
#define GRAY		GREY
#define WHITE   	31
#define YELLOW  	175
#define RED     	127
#define LBLUE   	233
#define GREEN   	255

