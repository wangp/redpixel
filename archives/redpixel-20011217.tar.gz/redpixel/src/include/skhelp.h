void send_long(long val);
long recv_long();
int receive_string(char *dest);
