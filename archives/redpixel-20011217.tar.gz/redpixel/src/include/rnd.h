int rnd();
void srnd(unsigned long seed);

int irnd();
void sirnd(unsigned long seed);

